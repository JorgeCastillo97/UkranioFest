/*@brief servidor.cpp
*  Este programa recibe números aleatorios simulando ser depósitos bancarios desde un cliente
*  acumulando dichos depósitos y retornando el total de estos.
*  Puede recuperandose de los paquetes perdidos mediante sockets por el protocolo UDP.
*  @autor José Pach Delgado
*/
#include <iostream>
#include "Respuesta.h"

using namespace std;

/********************************
*            SERVIDOR           *
*********************************/

int main( int argc, char * argv[] ) {

	Respuesta resp(7200);

	while( 1 ) {
		cout << "esperando solicitud" << endl;
		msg * msgs = resp.getRequest();
		int * res = (int *)msgs->arguments;
		
		msg msgR1;    
		msgR1.messageType = 1;    
		msgR1.requestId = msgs->requestId;    
		msgR1.operationId = suma;  
		msgR1.cuenta = msgs->cuenta;  
		int s = res[0];  
		cout << msgR1.cuenta << endl; 
		memcpy( msgR1.arguments, (char*)&s, sizeof(int) ); 
		cout << "Enviando respuesta" << endl;
		resp.sendReply( (char*)&msgR1 );

	} // end while
	
	return 0;
} // end main