#include "Respuesta.h"
#include <iostream>
using namespace std;

Respuesta::Respuesta( int pl ) {
	socketlocal = new SocketDatagrama(pl);
	msgR.cuenta      = 0;
	msgR.messageType = 1;
	msgR.operationId = 0;
	msgR.requestId   = 0;
	msgR.total       = 0;
} // end Respuesta


void Respuesta::sendReply( char *respuesta ) {
	PaqueteDatagrama p2( sizeof(msg) );
	p2.inicializaDatos( respuesta );
	socketlocal->envia(p2, 0);
} // end sendReply

struct mensaje * Respuesta::getRequest( void ) {
	while(1) {
		PaqueteDatagrama p( sizeof(msg) );
		socketlocal->recibe(p);
		msg * msgR1 = ( msg * )p.obtieneDatos();
		
		if( msgR.requestId  != msgR1->requestId ) {
			cout << "Server : " << msgR.requestId << endl;
			cout << "Cliente: " << msgR1->requestId << endl;
			msgR1->requestId = msgR.requestId;
		} else{
			int * res     = (int *)msgR1->arguments;
   			
			msgR.requestId++;
			msgR.total    =  msgR1->total;
			msgR.cuenta  += *res;
	   		msgR1->cuenta = msgR.cuenta;

			if( msgR.requestId == msgR1->total ) {
				msgR.requestId = 0;
				msgR.total     = 0;
				msgR.cuenta    = 0;
			}

   			
		} // end else

		return msgR1;
	} // end while
} // end getRequest

void Respuesta::setTotal( int n ) {
	if( n > 0 )
		msgR.total = n;
	else
		cout << "El valor debe ser mayor a cero >:("  << endl;
} // end setTotal
